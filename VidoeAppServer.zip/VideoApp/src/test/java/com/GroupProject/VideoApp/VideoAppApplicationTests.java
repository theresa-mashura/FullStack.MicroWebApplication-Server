package com.GroupProject.VideoApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
